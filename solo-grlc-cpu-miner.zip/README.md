# grlc-cpu-miner-solo
Easy cpu miner for garlic. This miner mines solo and uses the grlc.eu/miner node.
The settings are in the config.txt file.